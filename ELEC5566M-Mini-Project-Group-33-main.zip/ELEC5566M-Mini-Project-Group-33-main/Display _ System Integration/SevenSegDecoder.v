module SevenSegDecoder 
(
    input  [4:0] n,       // 4-bit input from the Adder
    output reg [6:0] hex  // 7-segment output {g, f, e, d, c, b, a}
);
    // Active-Low: 0 = ON, 1 = OFF
    always @(*) begin
        case (n)
            5'h0: hex = 7'b1000000;
            5'h1: hex = 7'b1111001;
            5'h2: hex = 7'b0100100;
            5'h3: hex = 7'b0110000;
            5'h4: hex = 7'b0011001;
            5'h5: hex = 7'b0010010;
            5'h6: hex = 7'b0000010;
            5'h7: hex = 7'b1111000;
            5'h8: hex = 7'b0000000;
            5'h9: hex = 7'b0011000;
            
				
            default: hex = 7'b1111111; // All OFF
				
        endcase
    end
endmodule