Number of Cards,Probability (Approx)
3 Cards,~35%
4 Cards,~5%
5 Cards,~0.5%
6 Cards,~0.01%


