
module LT24Top 
(
    // Global Clock/Reset
    // - Clock
    input              clock,
    // - Global Reset
    input              globalReset,
    // - Application Reset - for debug
    output             resetApp,
    
    // LT24 Interface
    output             LT24Wr_n,
    output             LT24Rd_n,
    output             LT24CS_n,
    output             LT24RS,
    output             LT24Reset_n,
    output [     15:0] LT24Data,
    output             LT24LCDOn,
	 
	 input [4:0] dealer_score, 
    input [4:0] player_score,
	 input dealer_hand[4:0],
	 input player_hand[4:0],
	 //input [2:0] player_card_count; 
	 //input [2:0] dealer_card_count; 
    
    // Physical pins for Dealer's displays
    output [6:0] HEX5, 
    output [6:0] HEX4,
    
    // Physical pins for Player's displays
    output [6:0] HEX1, 
    output [6:0] HEX0
	 
	 
	 
	 
	 
);

reg  [ 7:0] xAddr;
reg  [ 8:0] yAddr;
reg  [15:0] pixelData;
wire        pixelReady;
reg         pixelWrite;


// Sevensegment score===============

// dealer_score to the .sum input port
    Bin_to_Dec dealer 
	 (
        .sum  (dealer_score),
        .digit_0 (HEX4), 
        .digit_1 (HEX5)  
    );

    
    // player_score to the .sum input port
    Bin_to_Dec player 
	 (
        .sum  (player_score),
        .digit_0 (HEX0), 
        .digit_1 (HEX1)  
    );


// Constants 
localparam LCD_WIDTH = 240; 
localparam LCD_HEIGHT = 320; 
localparam GREEN = 16'h0340; 
localparam WHITE = 16'hFFFF; 
localparam BLACK = 16'h0000; 
localparam RED = 16'hF800;

LT24Display #(
    .WIDTH       (LCD_WIDTH  ),
    .HEIGHT      (LCD_HEIGHT ),
    .CLOCK_FREQ  (50000000   )
) Display (
    //Clock and Reset In
    .clock       (clock      ),
    .globalReset (globalReset),
    //Reset for User Logic
    .resetApp    (resetApp   ),
    //Pixel Interface
    .xAddr       (xAddr      ),
    .yAddr       (yAddr      ),
    .pixelData   (pixelData  ),
    .pixelWrite  (pixelWrite ),
    .pixelReady  (pixelReady ),
    //Use pixel addressing mode
    .pixelRawMode(1'b0       ),
    //Unused Command Interface
    .cmdData     (8'b0       ),
    .cmdWrite    (1'b0       ),
    .cmdDone     (1'b0       ),
    .cmdReady    (           ),
    //Display Connections
    .LT24Wr_n    (LT24Wr_n   ),
    .LT24Rd_n    (LT24Rd_n   ),
    .LT24CS_n    (LT24CS_n   ),
    .LT24RS      (LT24RS     ),
    .LT24Reset_n (LT24Reset_n),
    .LT24Data    (LT24Data   ),
    .LT24LCDOn   (LT24LCDOn  )
);

//
// X Counter
//
wire [7:0] xCount;
UpCounterNbit #
(
    .WIDTH    (          8),
    .MAX_VALUE(LCD_WIDTH-1)
) xCounter (
    .clock     (clock     ),
    .reset     (resetApp  ),
    .enable    (pixelReady),
    .countValue(xCount    )
);

//
// Y Counter
//
wire [8:0] yCount;
wire yCntEnable = pixelReady && (xCount == (LCD_WIDTH-1));
UpCounterNbit #(
    .WIDTH    (           9),
    .MAX_VALUE(LCD_HEIGHT-1)
) yCounter (
    .clock     (clock     ),
    .reset     (resetApp  ),
    .enable    (yCntEnable),
    .countValue(yCount    )
);

//
// Pixel Write
//
always @ (posedge clock or posedge resetApp) begin
    if (resetApp) begin
        pixelWrite <= 1'b0;
    end else begin
        //In this example we always set write high, and use pixelReady to detect when
        //to update the data.
        pixelWrite <= 1'b1;
        //You could also control pixelWrite and pixelData in a State Machine.
    end
end

//
// This is a simple test pattern generator.
//

reg inside_card; 
reg [3:0] card_val;
reg border; 
reg pixel_on;
integer i; 
reg [2:0] player_card_count; 
reg [2:0] dealer_card_count;
reg [3:0] dealer_hand [0:4];
reg [3:0] player_hand [0:4]; 

reg [5:0] x;
reg [5:0] y;


always @(posedge clock or posedge resetApp) begin 
	if (resetApp) begin 
	player_card_count <= player_score; // only for testing it will take the least three bits from of taotal score
	dealer_card_count <= dealer_score; // 
	end 
end















// We create a different colour for each pixel based on 
// the X-Y coordinate.
//
//wire [8:0] sine_y = 160 + (xCount % 64 > 32 ? (xCount % 32) : (32 - (xCount % 32)));
always @ (posedge clock or posedge resetApp) begin
    if (resetApp) begin
        pixelData <= 16'b0;
        xAddr     <= 8'b0;
        yAddr     <= 9'b0;
    end 
	 else if (pixelReady) begin
        xAddr <= xCount;
        yAddr <= yCount;

        // --- TABLE BACKGROUND (Dark Green Casino Felt) ---
pixelData <= 16'h0340; 

// Dynamic card ======================================
dealer_hand[0] <= 4'd1; // Card 1 should show 'A'
dealer_hand[1] <= 4'd2;  // Card 2 should show '2'
dealer_hand[2] <= 4'd3;  // Card 1 should show '3'
dealer_hand[3] <= 4'd4;  // Card 1 should show '4'
dealer_hand[4] <= 4'd5;  // Card 1 should show '5'

player_hand[0] <= 4'd13; // Card 1 should show 'K'
player_hand[2] <= 4'd12; // Card 1 should show 'Q'
player_hand[3] <= 4'd11; // Card 1 should show 'J'
player_hand[4] <= 4'd10; // Card 1 should show '10'
player_hand[1] <= 4'd9; // Card 1 should show '9'

// Dealer's and Player's cards with numbe================================
// --- Dealer's Cards ---
if (yCount >= 85 && yCount <= 171) begin
    inside_card = 0;
    border = 0;
    pixel_on = 0; // Reset for every pixel

    for (i = 0; i < 5; i = i + 1) begin
        if (i < dealer_card_count) begin
            // Check if current pixel is inside card 'i'
            if (xCount >= (10 + i*45) && xCount <= (40 + i*45)) begin
                inside_card = 1;

                // Calculate local coordinates for the number drawing
                // x will be 0-30, y will be 0-80
                x = xCount - (10 + i*45); 
                y = yCount - 85;

                //  FULL rectangle border logic
                if (xCount <= (10 + i*45 + 1) || xCount >= (40 + i*45 - 1) || yCount <= (85 + 1) || yCount >= (170)) begin
                    border = 1;
                end
                
                // Number Drawing Logic (Your specific module logic)
                if (x >= 4 && x <= 14 && y >= 4 && y <= 18) begin
                    case (dealer_hand[i]) // Use the index [i] here
                        4'd1:  if ( y == 4 || y == 11 || (x == 4 && y > 4) || (x == 14 && y > 4)) pixel_on = 1;
                        4'd2:  if (y == 4 || y == 11 || y == 18 || (x == 14 && y < 11) || (x == 4 && y > 11)) pixel_on = 1;
                        4'd3:  if (y == 4 || y == 11 || y == 18 || x == 14) pixel_on = 1;
                        4'd4:  if (y == 11 || x == 14 || (x == 4 && y < 11)) pixel_on = 1;
                        4'd5:  if (y == 4 || y == 11 || y == 18 || (x == 4 && y < 11) || (x == 14 && y > 11)) pixel_on = 1;
                        4'd6:  if (y == 4 || y == 11 || y == 18 || x == 4 || (x == 14 && y > 11)) pixel_on = 1;
                        4'd7:  if (y == 4 || x == 14) pixel_on = 1;
                        4'd8:  if (y == 4 || y == 11 || y == 18 || x == 4 || x == 14) pixel_on = 1;
                        4'd9:  if (y == 4 || y == 11 || y == 18 || x == 14 || (x == 4 && y < 11)) pixel_on = 1;
                        4'd10: if ((x >= 4 && x <= 5) || (x == 9 || x == 14 || y == 4 || y == 18)) pixel_on = 1;
                        4'd11: if (x == 14 || (y == 18 && x > 4) || (x == 4 && y > 14)) pixel_on = 1;
                        4'd12: if (x == 4 || x == 14 || y == 4 || y == 18 || (x == y && x > 10)) pixel_on = 1;
                        4'd13: if (x == 4 || (x + y == 18) || (y - x == 4)) pixel_on = 1;
                        default: pixel_on = 0;
                    endcase
                end
            end
        end
    end

    // Final color output for the Dealer row
    if (inside_card) begin
        if (border)      pixelData <= BLACK;
        else if (pixel_on) pixelData <= RED;   // Draw the number in Red
        else             pixelData <= WHITE; // Card body
    end else begin
        pixelData <= GREEN;
    end
end




// -----------Player's cards-------------------
else if (yCount >= 210 && yCount <= 297) begin
    inside_card = 0;
    border = 0;
    pixel_on = 0;

    for (i = 0; i < 5; i = i + 1) begin
        if (i < player_card_count) begin // Added the count check back in
            if (xCount >= (10 + i*45) && xCount <= (40 + i*45)) begin
                inside_card = 1;
                x = xCount - (10 + i*45); 
                y = yCount - 210;
					
					// Border logic
					if (xCount <= (10 + i*45 + 1) || xCount >= (40 + i*45 - 1) || yCount <= (210 + 1) || yCount >= (296)) begin
                    border = 1;					
                end
                
                //Expanded range to include top (4-18) AND bottom
                if (x >= 4 && x <= 14 && y >= 4 && y <= 18) begin
                    case (player_hand[i]) 
                        4'd1:  if (y==4 || y == 11 || (x == 4 && y > 4) || (x == 14 && y > 4)) pixel_on = 1;
                        4'd2:  if (y == 4 || y == 11 || y == 18 || (x == 14 && y < 11) || (x == 4 && y > 11)) pixel_on = 1;
                        4'd3:  if (y == 4 || y == 11 || y == 18 || x == 14) pixel_on = 1;
                        4'd4:  if (y == 11 || x == 14 || (x == 4 && y < 11)) pixel_on = 1;
                        4'd5:  if (y == 4 || y == 11 || y == 18 || (x == 4 && y < 11) || (x == 14 && y > 11)) pixel_on = 1;
                        4'd6:  if (y == 4 || y == 11 || y == 18 || x == 4 || (x == 14 && y > 11)) pixel_on = 1;
                        4'd7:  if (y == 4 || x == 14) pixel_on = 1;
                        4'd8:  if (y == 4 || y == 11 || y == 18 || x == 4 || x == 14) pixel_on = 1;
                        4'd9:  if (y == 4 || y == 11 || y == 18 || x == 14 || (x == 4 && y < 11)) pixel_on = 1;
                        4'd10: if ((x >= 4 && x <= 5) || (x == 8 || x == 14 || ((y == 4 || y == 18) && (x >= 8 && x <= 14)))) pixel_on = 1;
                        4'd11: if (x == 14 || (y == 18 && x > 4) || (x == 4 && y > 14)) pixel_on = 1;
                        4'd12: if (x == 4 || x == 14 || y == 4 || y == 18 || (x == y && x > 10)) pixel_on = 1;
                        4'd13: if (x == 4 || (x + y == 18) || (y - x == 4)) pixel_on = 1;
                        default: pixel_on = 0;
                    endcase
                end
            end
     end  
   
end

   // Final color output for the player row
    if (inside_card) begin
        if (border)      pixelData <= BLACK;
        else if (pixel_on) pixelData <= RED;   // Draw the number in Red
        else             pixelData <= WHITE; // Card body
    end else begin
        pixelData <= GREEN;
    end
end


// =============================================================================================
// LINE 1: "WELCOME TO THE CASINO" (Centered, Y: 10 to 20)
// Total width of text is approx 150 pixels. 
// Starting X around 45 to center it between 0 and 239.

if (yCount >= 10 && yCount <= 20) begin
    // 'W' (Shifted from 45-55 to 25-35)
    if ((xCount >= 25 && xCount <= 27 && yCount >= 10 && yCount <= 20) ||
        (xCount >= 33 && xCount <= 35 && yCount >= 10 && yCount <= 20) ||
        (xCount >= 27 && xCount <= 33 && yCount >= 18 && yCount <= 20) ||
        (xCount >= 29 && xCount <= 31 && yCount >= 14 && yCount <= 20)) begin
        pixelData <= WHITE; 
    end
    // 'E' (Shifted from 58-65 to 38-45)
    else if ((xCount >= 38 && xCount <= 40 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 40 && xCount <= 45 && (yCount <= 12 || yCount >= 18 || (yCount >= 14 && yCount <= 16)))) begin
        pixelData <= WHITE; 
    end
    // 'L' (Shifted from 68-75 to 48-55)
    else if ((xCount >= 48 && xCount <= 50 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 50 && xCount <= 55 && yCount >= 18 && yCount <= 20)) begin
        pixelData <= WHITE; 
    end
    // 'C' (Shifted from 78-85 to 58-65)
    else if ((xCount >= 58 && xCount <= 60 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 60 && xCount <= 65 && (yCount <= 12 || yCount >= 18))) begin
        pixelData <= WHITE; 
    end
    // 'O' (Shifted from 88-95 to 68-75)
    else if ((xCount >= 68 && xCount <= 70 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 73 && xCount <= 75 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 70 && xCount <= 73 && (yCount <= 12 || yCount >= 18))) begin
        pixelData <= WHITE; 
    end
    // 'R' (Shifted from 98-105 to 78-85)
    else if ((xCount >= 78 && xCount <= 80 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 80 && xCount <= 85 && (yCount <= 12 || (yCount >= 14 && yCount <= 16))) ||
             (xCount >= 83 && xCount <= 85 && yCount >= 12 && yCount <= 15) ||
             (xCount >= 82 && xCount <= 85 && yCount >= 16 && yCount <= 20)) begin
        pixelData <= WHITE; 
    end
    // 'E' (Shifted from 108-115 to 88-95)
    else if ((xCount >= 88 && xCount <= 90 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 90 && xCount <= 95 && (yCount <= 12 || yCount >= 18 || (yCount >= 14 && yCount <= 16)))) begin
        pixelData <= WHITE; 
    end
    
    // (SPACE)
    
    // 'T' (Shifted from 120-128 to 100-108)
    else if ((xCount >= 103 && xCount <= 105 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 100 && xCount <= 108 && yCount <= 12)) begin
        pixelData <= WHITE; 
    end
    // 'O' (Shifted from 131-138 to 111-118)
    else if ((xCount >= 111 && xCount <= 113 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 116 && xCount <= 118 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 113 && xCount <= 116 && (yCount <= 12 || yCount >= 18))) begin
        pixelData <= WHITE; 
    end
    
    // (SPACE)
    
    // 'T' (Shifted from 143-151 to 123-131)
    else if ((xCount >= 126 && xCount <= 128 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 123 && xCount <= 131 && yCount <= 12)) begin
        pixelData <= WHITE; 
    end
    // 'H' (Shifted from 154-163 to 134-143)
    else if ((xCount >= 134 && xCount <= 136 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 141 && xCount <= 143 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 136 && xCount <= 141 && yCount >= 14 && yCount <= 16)) begin
        pixelData <= WHITE; 
    end
    // 'E' (Shifted from 166-173 to 146-153)
    else if ((xCount >= 146 && xCount <= 148 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 148 && xCount <= 153 && (yCount <= 12 || yCount >= 18 || (yCount >= 14 && yCount <= 16)))) begin
        pixelData <= WHITE; 
    end
    
    // (SPACE)
    
    // 'C' (Shifted from 181-188 to 161-168)
    else if ((xCount >= 161 && xCount <= 163 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 163 && xCount <= 168 && (yCount <= 12 || yCount >= 18))) begin
        pixelData <= WHITE; 
    end
    // 'A' (Shifted from 191-200 to 171-180)
    else if ((xCount >= 171 && xCount <= 173 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 178 && xCount <= 180 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 173 && xCount <= 178 && (yCount <= 12 || yCount >= 14 && yCount <= 16))) begin
        pixelData <= WHITE; 
    end
    // 'S' (Shifted from 203-208 to 183-188)
    else if ((xCount >= 183 && xCount <= 188 && (yCount <= 12 || yCount >= 18 || (yCount >= 14 && yCount <= 16))) ||
             (xCount >= 183 && xCount <= 185 && yCount >= 12 && yCount <= 14) ||
             (xCount >= 186 && xCount <= 188 && yCount >= 16 && yCount <= 18)) begin
        pixelData <= WHITE; 
    end
    // 'I' (Shifted from 213-217 to 193-197)
    else if ((xCount >= 193 && xCount <= 195 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 191 && xCount <= 197 && (yCount <= 12 || yCount >= 18))) begin
        pixelData <= WHITE; 
    end
    // 'N' (Shifted from 220-229 to 200-209)
    else if ((xCount >= 200 && xCount <= 202 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 207 && xCount <= 209 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 202 && xCount <= 207 && xCount == yCount + 190)) begin // Diagonal adjusted
        pixelData <= WHITE; 
    end
    // 'O' (Shifted from 232-239 to 212-219)
    else if ((xCount >= 212 && xCount <= 214 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 217 && xCount <= 219 && yCount >= 10 && yCount <= 20) ||
             (xCount >= 214 && xCount <= 217 && (yCount <= 12 || yCount >= 18))) begin
        pixelData <= WHITE; 
    end
end

// =========================================================
// LINE 2: "BLACK JACK" (Your bold custom font, centered!)

// --- LETTER 'B' ---
else if ((xCount >= 31 && xCount <= 34 && yCount >= 35 && yCount <= 47) ||
    (xCount >= 34 && xCount <= 39 && yCount >= 35 && yCount <= 37) ||
    (xCount >= 34 && xCount <= 39 && yCount >= 40 && yCount <= 42) ||
    (xCount >= 34 && xCount <= 39 && yCount >= 45 && yCount <= 47) ||
    (xCount >= 39 && xCount <= 41 && yCount >= 37 && yCount <= 40) ||
    (xCount >= 39 && xCount <= 41 && yCount >= 42 && yCount <= 45)
) begin
    pixelData <= RED; // Bold Red text
end

// --- LETTER 'L' ---
else if ((xCount >= 51 && xCount <= 54 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 54 && xCount <= 61 && yCount >= 44 && yCount <= 47)) begin
    pixelData <= RED;
end

// --- LETTER 'A' ---
else if ((xCount >= 71 && xCount <= 74 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 81 && xCount <= 84 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 74 && xCount <= 81 && yCount >= 35 && yCount <= 37) ||
         (xCount >= 74 && xCount <= 81 && yCount >= 40 && yCount <= 42)) begin
    pixelData <= RED;
end

// --- LETTER 'C' ---
else if ((xCount >= 91 && xCount <= 94 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 94 && xCount <= 103 && yCount >= 35 && yCount <= 37) ||
         (xCount >= 94 && xCount <= 103 && yCount >= 44 && yCount <= 47)) begin
    pixelData <= RED;
end

// --- LETTER 'K' ---
else if ((xCount >= 111 && xCount <= 114 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 114 && xCount <= 121 && yCount >= 40 && yCount <= 42) ||
         (xCount >= 121 && xCount <= 124 && yCount >= 35 && yCount <= 37) ||
         (xCount >= 121 && xCount <= 124 && yCount >= 42 && yCount <= 47)) begin
    pixelData <= RED;
end

// --- LETTER 'J' ---
else if ((xCount >= 136 && xCount <= 146 && yCount >= 44 && yCount <= 47) ||
         (xCount >= 142 && xCount <= 145 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 136 && xCount <= 139 && yCount >= 41 && yCount <= 47)) begin
    pixelData <= RED;
end

// --- LETTER 'A' ---
else if ((xCount >= 156 && xCount <= 159 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 166 && xCount <= 169 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 159 && xCount <= 166 && yCount >= 35 && yCount <= 37) ||
         (xCount >= 159 && xCount <= 166 && yCount >= 40 && yCount <= 42)) begin
    pixelData <= RED;
end

// --- LETTER 'C' ---
else if ((xCount >= 176 && xCount <= 179 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 179 && xCount <= 188 && yCount >= 35 && yCount <= 37) ||
         (xCount >= 179 && xCount <= 188 && yCount >= 44 && yCount <= 47)) begin
    pixelData <= RED;
end

// --- LETTER 'K' ---
else if ((xCount >= 196 && xCount <= 199 && yCount >= 35 && yCount <= 47) ||
         (xCount >= 199 && xCount <= 206 && yCount >= 40 && yCount <= 42) ||
         (xCount >= 206 && xCount <= 209 && yCount >= 35 && yCount <= 37) ||
         (xCount >= 206 && xCount <= 209 && yCount >= 42 && yCount <= 47)) begin
    pixelData <= RED;
end

end
	 
	 
// "DEALER" (Y: 70 to 78, centered)
// =========================================================
else if (yCount >= 70 && yCount <= 78) begin
    // 'D'
    if ((xCount >= 95 && xCount <= 96 && yCount >= 70 && yCount <= 78) || 
        (xCount >= 96 && xCount <= 101 && (yCount == 70 || yCount == 78)) ||
        (xCount >= 101 && xCount <= 102 && yCount >= 71 && yCount <= 77)) begin
        pixelData <= BLACK;
    end
    // 'E'
    else if ((xCount >= 105 && xCount <= 106 && yCount >= 70 && yCount <= 78) ||
             (xCount >= 106 && xCount <= 110 && (yCount == 70 || yCount == 74 || yCount == 78))) begin
        pixelData <= BLACK;
    end
    // 'A'
    else if ((xCount >= 113 && xCount <= 114 && yCount >= 70 && yCount <= 78) ||
             (xCount >= 118 && xCount <= 119 && yCount >= 70 && yCount <= 78) ||
             (xCount >= 114 && xCount <= 118 && (yCount == 70 || yCount == 74))) begin
        pixelData <= BLACK;
    end
    // 'L'
    else if ((xCount >= 122 && xCount <= 123 && yCount >= 70 && yCount <= 78) ||
             (xCount >= 123 && xCount <= 127 && yCount == 78)) begin
        pixelData <= BLACK;
    end
    // 'E'
    else if ((xCount >= 130 && xCount <= 131 && yCount >= 70 && yCount <= 78) ||
             (xCount >= 131 && xCount <= 135 && (yCount == 70 || yCount == 74 || yCount == 78))) begin
        pixelData <= BLACK;
    end
    // 'R'
    else if ((xCount >= 138 && xCount <= 139 && yCount >= 70 && yCount <= 78) ||
             (xCount >= 139 && xCount <= 143 && (yCount == 70 || yCount == 74)) ||
             (xCount >= 143 && xCount <= 144 && yCount >= 71 && yCount <= 73) ||
             (xCount >= 142 && xCount <= 144 && yCount >= 75 && yCount <= 78)) begin
        pixelData <= BLACK;
    end
end


//  "PLAYER" (Y: 193 to 201, centered)
// =========================================================
else if (yCount >= 193 && yCount <= 201) begin
    // 'P'
    if ((xCount >= 95 && xCount <= 96 && yCount >= 193 && yCount <= 201) ||
        (xCount >= 96 && xCount <= 101 && (yCount == 193 || yCount == 197)) ||
        (xCount >= 101 && xCount <= 102 && yCount >= 194 && yCount <= 196)) begin
        pixelData <= BLACK;
    end
    // 'L'
    else if ((xCount >= 105 && xCount <= 106 && yCount >= 193 && yCount <= 201) ||
             (xCount >= 106 && xCount <= 110 && yCount == 201)) begin
        pixelData <= BLACK;
    end
    // 'A'
    else if ((xCount >= 113 && xCount <= 114 && yCount >= 193 && yCount <= 201) ||
             (xCount >= 118 && xCount <= 119 && yCount >= 193 && yCount <= 201) ||
             (xCount >= 114 && xCount <= 118 && (yCount == 193 || yCount == 197))) begin
        pixelData <= BLACK;
    end
    // 'Y'
    else if ((xCount >= 122 && xCount <= 123 && yCount >= 193 && yCount <= 197) ||
             (xCount >= 127 && xCount <= 128 && yCount >= 193 && yCount <= 197) ||
             (xCount >= 123 && xCount <= 127 && yCount == 197) ||
             (xCount >= 125 && xCount <= 126 && yCount >= 198 && yCount <= 201)) begin
        pixelData <= BLACK;
    end
    // 'E'
    else if ((xCount >= 132 && xCount <= 133 && yCount >= 193 && yCount <= 201) ||
             (xCount >= 133 && xCount <= 137 && (yCount == 193 || yCount == 197 || yCount == 201))) begin
        pixelData <= BLACK;
    end
    // 'R'
    else if ((xCount >= 140 && xCount <= 141 && yCount >= 193 && yCount <= 201) ||
             (xCount >= 141 && xCount <= 145 && (yCount == 193 || yCount == 197)) ||
             (xCount >= 145 && xCount <= 146 && yCount >= 194 && yCount <= 196) ||
             (xCount >= 144 && xCount <= 146 && yCount >= 198 && yCount <= 201)) begin
        pixelData <= BLACK;
    end
end
	 
	 
	 
end

endmodule


 */

module UpCounterNbit #
(
    parameter WIDTH = 10,               //10bit wide
    parameter INCREMENT = 1,            //Value to increment counter by each cycle
    parameter MAX_VALUE = (2**WIDTH)-1  //Maximum value default is 2^WIDTH - 1
)(   
    input                    clock,
    input                    reset,
    input                    enable,    //Increments when enable is high
    output reg [(WIDTH-1):0] countValue //Output is declared as "WIDTH" bits wide
);

always @ (posedge clock) begin
    if (reset) begin
        //When reset is high, set back to 0
        countValue <= {(WIDTH){1'b0}};
    end else if (enable) begin
        //Otherwise counter is not in reset
        if (countValue >= MAX_VALUE[WIDTH-1:0]) begin
            //If the counter value is equal or exceeds the maximum value
            countValue <= {(WIDTH){1'b0}};   //Reset back to 0
        end else begin
            //Otherwise increment
            countValue <= countValue + INCREMENT[WIDTH-1:0];
        end
    end
end

endmodule



