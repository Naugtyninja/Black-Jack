module Test_Blackjack_Display
(
    input  [4:0] SW,   // Use sliding switches SW[4:0] to fake the score
    output [6:0] HEX0, // Pins for units display
    output [6:0] HEX1  // Pins for tens display
);

    // Instantiate your Bin_to_Dec module
    // This takes the binary value of the switches and puts it on the HEX screens!
    Bin_to_Dec test_driver
	 (
        .sum  (SW), 
        .HEX0 (HEX0),
        .HEX1 (HEX1)
    );

endmodule