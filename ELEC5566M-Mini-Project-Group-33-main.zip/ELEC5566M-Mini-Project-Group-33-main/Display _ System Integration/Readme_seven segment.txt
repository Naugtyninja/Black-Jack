To deplay the score from the Top layer file -

// Ex-top module 

module Blackjack_Top  
(
    // real DE1-SoC physical board pins
    output [6:0] HEX0, HEX1, HEX4, HEX5
);

    wire [4:0] current_player_score   // Will come from the game logic
    wire [4:0] current_dealer_score  // Will come from the game logic

    // We only pass the dealer and player scores!
    // We connect the HEX outputs by simply matching the physical wire names.
    Scores my_display_system 
 (
        .dealer_score (current_dealer_score),
        .player_score (current_player_score),
        .HEX0(HEX0), 
        .HEX1(HEX1), 
        .HEX4(HEX4), 
        .HEX5(HEX5)
    );

endmodule