module Scores
(
    input [4:0] dealer_score, 
    input [4:0] player_score, 
    
    // Physical pins for Dealer's displays
    output [6:0] HEX5, 
    output [6:0] HEX4,
    
    // Physical pins for Player's displays
    output [6:0] HEX1, 
    output [6:0] HEX0
);

    
    // dealer_score to the .sum input port
    Bin_to_Dec dealer 
	 (
        .sum  (dealer_score),
        .digit_0 (HEX4), 
        .digit_1 (HEX5)  
    );

    
    // player_score to the .sum input port
    Bin_to_Dec player 
	 (
        .sum  (player_score),
        .digit_0 (HEX0), 
        .digit_1 (HEX1)  
    );

endmodule