module Bin_to_Dec 
(
    input  [4:0] sum, // Up to 31
	 output [6:0] digit_1,  // Connected to the 1st 7-segment display pins
    output [6:0] digit_0  // Connected to the 2nd 7-segment display pins
);
	


	reg [3:0] tens;
	reg [3:0] units;

always @(*) begin
	if (sum >= 30 && sum<40) begin
        tens  = 4'd3;                // Light up the "1" on the 2nd HEX
        units = sum- 5'd30; // Subtract 20 to get the "Units"
    end 
	 else if (sum>= 20 && sum<30) begin
        tens  = 4'd2;                // Light up the "1" on the 2nd HEX
        units = sum - 5'd20; // Subtract 10 to get the "Units" 
    end 
    else if (sum>= 10 && sum<20) begin
        tens  = 4'd1;                // Light up the "1" on the 2nd HEX
        units = sum - 5'd10; // Subtract 10 to get the "Units" 
    end 
    else begin
        tens  = 4'hF;                // Keep the 2nd HEX blank (Off)
        units = sum[3:0];    // Just show the 4-bit sum
    end
end 
	 
	 
	 SevenSegDecoder digit0 
	 (
        .n  (units),    // Takes the 'units' result from your math
        .hex(digit_0)      // Connected to the 1st 7-segment display pins
    );

    // 2nd Instance: The Tens Digit (Left side)
    SevenSegDecoder digit1 
	 (
        .n  (tens),     // Takes the 'tens' result (1, 2, or 3)
        .hex(digit_1)      // Connected to the 2nd 7-segment display pins
    );

    

endmodule