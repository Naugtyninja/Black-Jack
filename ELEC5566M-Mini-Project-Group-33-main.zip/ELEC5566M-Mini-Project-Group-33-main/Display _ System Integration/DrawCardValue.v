module DrawCardValue (
    input [3:0] value,
    input [5:0] x,      // active_cx
    input [6:0] y,      // active_cy
    output reg pixel_on // char_pixel
);

always @(*) begin
    pixel_on = 0;
    // We draw the numbers in a small box at the top-left (e.g., x:4-14, y:4-18)
    if (x >= 4 && x <= 14 && y >= 4 && y <= 18) begin
        case (value)
            4'd1:  // 'A'
                if (x == 9 || y == 4 || y == 11 || (x == 4 && y > 4) || (x == 14 && y > 4)) pixel_on = 1;
            4'd2:  // '2'
                if (y == 4 || y == 11 || y == 18 || (x == 14 && y < 11) || (x == 4 && y > 11)) pixel_on = 1;
            4'd3:  // '3'
                if (y == 4 || y == 11 || y == 18 || x == 14) pixel_on = 1;
            4'd4:  // '4'
                if (y == 11 || x == 14 || (x == 4 && y < 11)) pixel_on = 1;
            4'd5:  // '5'
                if (y == 4 || y == 11 || y == 18 || (x == 4 && y < 11) || (x == 14 && y > 11)) pixel_on = 1;
            4'd6:  // '6'
                if (y == 4 || y == 11 || y == 18 || x == 4 || (x == 14 && y > 11)) pixel_on = 1;
            4'd7:  // '7'
                if (y == 4 || x == 14) pixel_on = 1;
            4'd8:  // '8'
                if (y == 4 || y == 11 || y == 18 || x == 4 || x == 14) pixel_on = 1;
            4'd9:  // '9'
                if (y == 4 || y == 11 || y == 18 || x == 14 || (x == 4 && y < 11)) pixel_on = 1;
            4'd10: // '10' (Combined 1 and 0)
                if ((x >= 4 && x <= 5) || // The '1'
                    (x == 8 || x == 14 || y == 4 || y == 18)) // The '0'
                    pixel_on = 1;
            4'd11: // 'J'
                if (x == 14 || (y == 18 && x > 4) || (x == 4 && y > 14)) pixel_on = 1;
            4'd12: // 'Q'
                if (x == 4 || x == 14 || y == 4 || y == 18 || (x == y && x > 10)) pixel_on = 1;
            4'd13: // 'K'
                if (x == 4 || (x + y == 18) || (y - x == 4)) pixel_on = 1;
            default: pixel_on = 0;
        endcase
    end
end
endmodule