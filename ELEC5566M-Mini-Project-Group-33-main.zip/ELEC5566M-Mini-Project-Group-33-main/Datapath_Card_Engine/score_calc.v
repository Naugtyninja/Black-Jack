module score_calc(
    input [3:0] c0, c1, c2, c3, c4,
    output reg [5:0] score
);

reg [5:0] sum;
reg [2:0] ace_count;

// Function to convert card to value
function [3:0] card_val;
    input [3:0] c;
    begin
        case(c)
            4'd1: card_val = 4'd11;           // Ace
            4'd11,4'd12,4'd13: card_val = 4'd10; // Face cards
            default: card_val = c;
        endcase
    end
endfunction

// Function to check if card is Ace
function is_ace;
    input [3:0] c;
    begin
        is_ace = (c == 4'd1);
    end
endfunction

always @(*) begin
    sum = 0;
    ace_count = 0;

    // Add all cards
    sum = sum + card_val(c0);
    sum = sum + card_val(c1);
    sum = sum + card_val(c2);
    sum = sum + card_val(c3);
    sum = sum + card_val(c4);

    // Count Aces
    ace_count = is_ace(c0) + is_ace(c1) + is_ace(c2) + is_ace(c3) + is_ace(c4);

    // Adjust Ace from 11 → 1 if needed
    if (sum > 21 && ace_count > 0) begin sum = sum - 10; ace_count = ace_count - 1; end
    if (sum > 21 && ace_count > 0) begin sum = sum - 10; ace_count = ace_count - 1; end
    if (sum > 21 && ace_count > 0) begin sum = sum - 10; ace_count = ace_count - 1; end
    if (sum > 21 && ace_count > 0) begin sum = sum - 10; ace_count = ace_count - 1; end
    if (sum > 21 && ace_count > 0) begin sum = sum - 10; ace_count = ace_count - 1; end

    score = sum;
end

endmodule
