## Datapath & Card Engine 

This module implements the core logic of the Blackjack system.

### Features:
- Pseudo-random card generator (LFSR)
- Player and dealer hand storage
- Blackjack score calculation
- Ace handling (1 or 11 adjustment)

### Files Included:
- lfsr_card_gen.v
- hand_storage.v
- score_calc.v
- blackjack_datapath.v

Author: Bhavitha Avula
