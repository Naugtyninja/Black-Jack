module blackjack_datapath(
    input clk,
    input reset,
    input deal_player,
    input deal_dealer,
    output [5:0] player_score,
    output [5:0] dealer_score
);

// Random card
wire [3:0] card;

lfsr_card_gen rng (
    .clk(clk),
    .reset(reset),
    .card(card)
);

// Player hand
wire [3:0] p0,p1,p2,p3,p4;
wire [2:0] p_count;

hand_storage player (
    .clk(clk),
    .reset(reset),
    .deal(deal_player),
    .card_in(card),
    .c0(p0), .c1(p1), .c2(p2), .c3(p3), .c4(p4),
    .count(p_count)
);

// Dealer hand
wire [3:0] d0,d1,d2,d3,d4;
wire [2:0] d_count;

hand_storage dealer (
    .clk(clk),
    .reset(reset),
    .deal(deal_dealer),
    .card_in(card),
    .c0(d0), .c1(d1), .c2(d2), .c3(d3), .c4(d4),
    .count(d_count)
);

// Score calculation
score_calc player_score_calc (
    .c0(p0), .c1(p1), .c2(p2), .c3(p3), .c4(p4),
    .score(player_score)
);

score_calc dealer_score_calc (
    .c0(d0), .c1(d1), .c2(d2), .c3(d3), .c4(d4),
    .score(dealer_score)
);

endmodule
