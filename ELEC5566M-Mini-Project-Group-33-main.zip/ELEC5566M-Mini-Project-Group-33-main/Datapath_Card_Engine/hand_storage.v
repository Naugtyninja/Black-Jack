module hand_storage(
    input clk,
    input reset,
    input deal,
    input [3:0] card_in,
    output reg [3:0] c0, c1, c2, c3, c4,
    output reg [2:0] count
);

always @(posedge clk or posedge reset) begin
    if (reset) begin
        count <= 0;
        c0 <= 0; c1 <= 0; c2 <= 0; c3 <= 0; c4 <= 0;
    end
    else if (deal && count < 5) begin
        case(count)
            0: c0 <= card_in;
            1: c1 <= card_in;
            2: c2 <= card_in;
            3: c3 <= card_in;
            4: c4 <= card_in;
        endcase
        count <= count + 1;
    end
end

endmodule
