module lfsr_card_gen(
    input clk,
    input reset,
    output [3:0] card
);

reg [7:0] lfsr;

always @(posedge clk or posedge reset) begin
    if (reset)
        lfsr <= 8'hA5;
    else
        lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};
end

assign card = (lfsr % 13) + 1;

endmodule
