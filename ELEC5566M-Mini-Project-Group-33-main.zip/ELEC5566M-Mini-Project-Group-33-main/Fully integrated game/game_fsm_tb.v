// ============================================================
// game_fsm_tb.v
// Author: Muhammad Ayan Tariq
// Code to check FSM state 
// ============================================================

`timescale 1ns/1ps

module game_fsm_tb;

// Declare inputs as reg
reg clk;
reg reset_n;
reg btn_start;
reg btn_hit;
reg btn_stand;
reg player_bust;
reg dealer_done;

// Declare outputs as wire
wire deal_card;
wire dealer_go;
wire player_active;
wire show_result;
wire [1:0] result_code;
wire [2:0] state_out;

// Connect testbench to your FSM
game_fsm uut (
    .clk           (clk),
    .reset_n       (reset_n),
    .btn_start     (btn_start),
    .btn_hit       (btn_hit),
    .btn_stand     (btn_stand),
    .player_bust   (player_bust),
    .dealer_done   (dealer_done),
    .deal_card     (deal_card),
    .dealer_go     (dealer_go),
    .player_active (player_active),
    .show_result   (show_result),
    .result_code   (result_code),
    .state_out     (state_out)
);

// Clock generation every 10ns = 50 MHz 
initial clk = 0;
always #10 clk = ~clk;

// Main test sequence as each step check part of the FSM behaviour
initial begin
    $display("=== Blackjack FSM Test ===");
    $display("By: Muhammad Ayan Tariq");
    $display("==============================");

    // defaults state
    reset_n     = 0;
    btn_start   = 0;
    btn_hit     = 0;
    btn_stand   = 0;
    player_bust = 0;
    dealer_done = 0;

    // Hold reset for 3 clock cycles
    repeat(3) @(posedge clk);
    reset_n = 1;
    @(posedge clk); #1;

    // -----------------------------------------------
    // TEST 1: After reset, should be in IDLE (state 0)
    // -----------------------------------------------
    if (state_out === 3'd0)
        $display("PASS: TEST 1 - Reset correctly goes to IDLE");
    else
        $display("FAIL: TEST 1 - Expected IDLE(0), got %0d", state_out);

    // -----------------------------------------------
    // TEST 2: Press btn_start - should go to DEAL (1)
    // -----------------------------------------------
    btn_start = 1;
    @(posedge clk); #1;
    btn_start = 0;
    if (state_out === 3'd1)
        $display("PASS: TEST 2 - btn_start goes to DEAL");
    else
        $display("FAIL: TEST 2 - Expected DEAL(1), got %0d", state_out);

    // -----------------------------------------------
    // TEST 3: DEAL goes to PLAYER_TURN (2) automatically
    // -----------------------------------------------
    @(posedge clk); #1;
    if (state_out === 3'd2)
        $display("PASS: TEST 3 - DEAL goes to PLAYER_TURN");
    else
        $display("FAIL: TEST 3 - Expected PLAYER_TURN(2), got %0d", state_out);

    // -----------------------------------------------
    // TEST 4: player_active should be 1 in PLAYER_TURN
    // -----------------------------------------------
    if (player_active === 1'b1)
        $display("PASS: TEST 4 - player_active is 1 in PLAYER_TURN");
    else
        $display("FAIL: TEST 4 - player_active should be 1");
		  
	 // ------------------------------------------------
	 // TEST 5A: Hit should stay in PLAYER_TURN
	 // ------------------------------------------------
	   btn_hit = 1;
           @(posedge clk); #1;
           btn_hit = 0;

      if (state_out === 3'd2)
      $display("PASS: TEST 5A - btn_hit keeps FSM in PLAYER_TURN");
       else
      $display("FAIL: TEST 5A - Expected PLAYER_TURN(2), got %0d", state_out);

    // -----------------------------------------------
    // TEST 5: btn_stand goes to DEALER_TURN (3)
    // -----------------------------------------------
    btn_stand = 1;
    @(posedge clk); #1;
    btn_stand = 0;
    if (state_out === 3'd3)
        $display("PASS: TEST 5 - btn_stand goes to DEALER_TURN");
    else
        $display("FAIL: TEST 5 - Expected DEALER_TURN(3), got %0d", state_out);

    // -----------------------------------------------
    // TEST 6: dealer_go should be 1 in DEALER_TURN
    // -----------------------------------------------
    if (dealer_go === 1'b1)
        $display("PASS: TEST 6 - dealer_go is 1 in DEALER_TURN");
    else
        $display("FAIL: TEST 6 - dealer_go should be 1");

    // -----------------------------------------------
    // TEST 7: dealer_done goes to RESULT (4)
    // -----------------------------------------------
    dealer_done = 1;
    @(posedge clk); #1;
    dealer_done = 0;
    if (state_out === 3'd4)
        $display("PASS: TEST 7 - dealer_done goes to RESULT");
    else
        $display("FAIL: TEST 7 - Expected RESULT(4), got %0d", state_out);

    // -----------------------------------------------
    // TEST 8: show_result should be 1 in RESULT
    // -----------------------------------------------
    if (show_result === 1'b1)
        $display("PASS: TEST 8 - show_result is 1 in RESULT");
    else
        $display("FAIL: TEST 8 - show_result should be 1");

    // -----------------------------------------------
    // TEST 9: btn_start in RESULT goes back to IDLE
    // -----------------------------------------------
    btn_start = 1;
    @(posedge clk); #1;
    btn_start = 0;
    if (state_out === 3'd0)
        $display("PASS: TEST 9 - RESULT goes back to IDLE");
    else
        $display("FAIL: TEST 9 - Expected IDLE(0), got %0d", state_out);

    // -----------------------------------------------
    // TEST 10: Reset from any state goes to IDLE
    // -----------------------------------------------
    btn_start = 1;
    @(posedge clk); #1;
    btn_start = 0;

    reset_n = 0;
    #1;
    if (state_out === 3'd0)
        $display("PASS: TEST 10 - reset_n returns to IDLE from any state");
    else
        $display("FAIL: TEST 10 - Expected IDLE(0), got %0d", state_out);

    reset_n = 1;
    @(posedge clk); #1;
	 
    // -----------------------------------------------
    // TEST 11: Start again and simulate player bust
    // -----------------------------------------------
    btn_start = 1;
    @(posedge clk); #1;
    btn_start = 0;

    if (state_out === 3'd1)
        $display("PASS: TEST 11A - btn_start goes to DEAL");
    else
        $display("FAIL: TEST 11A - Expected DEAL(1), got %0d", state_out);

    @(posedge clk); #1;   // DEAL -> PLAYER_TURN

    if (state_out === 3'd2)
        $display("PASS: TEST 11B - DEAL goes to PLAYER_TURN");
    else
        $display("FAIL: TEST 11B - Expected PLAYER_TURN(2), got %0d", state_out);

    player_bust = 1;
    @(posedge clk); #1;
	 
    if (state_out === 3'd4)
        $display("PASS: TEST 11C - player_bust goes to RESULT");
    else
        $display("FAIL: TEST 11C - Expected RESULT(4), got %0d", state_out);
		  
     

    $display("==============================");
    $display("All tests complete");
    $display("==============================");
    $stop;
end

endmodule