// game_fsm.v
// Author: Muhammad Ayan Tariq

module game_fsm (
    input  wire        clk,
    input  wire        reset_n,
    input  wire        btn_start,
    input  wire        btn_hit,
    input  wire        btn_stand,
    input  wire        player_bust,
    input  wire        dealer_done,
    output reg         deal_card,
    output reg         dealer_go,
    output reg         player_active,
    output reg         show_result,
    output reg  [1:0]  result_code,
    output wire [2:0]  state_out
);


// State parameters

parameter IDLE        = 3'd0;
parameter DEAL        = 3'd1;
parameter PLAYER_TURN = 3'd2;
parameter DEALER_TURN = 3'd3;
parameter RESULT      = 3'd4;


// State registers

reg [2:0] state;
reg [2:0] next_state;
assign state_out = state;


// Edge detection registers - one pulse per button press

reg btn_hit_prev;
reg btn_start_prev;
reg btn_stand_prev;

wire btn_hit_edge;
wire btn_start_edge;
wire btn_stand_edge;

// Edge fires only on the first clock tick the button goes HIGH
assign btn_hit_edge   = btn_hit   && !btn_hit_prev;
assign btn_start_edge = btn_start && !btn_start_prev;
assign btn_stand_edge = btn_stand && !btn_stand_prev;


// Clocked state register - updates on clock edge also stores previous button states for edge detection

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        state          <= IDLE;
        btn_hit_prev   <= 0;
        btn_start_prev <= 0;
        btn_stand_prev <= 0;
    end else begin
        state          <= next_state;
        btn_hit_prev   <= btn_hit;
        btn_start_prev <= btn_start;
        btn_stand_prev <= btn_stand;
    end
end


// Next-state logic: combinational

always @(*) begin
    next_state = state;
    case (state)
        IDLE: begin
            if (btn_start_edge)
                next_state = DEAL;
        end
        DEAL: begin
            next_state = PLAYER_TURN;
        end
        PLAYER_TURN: begin
            if (player_bust)
                next_state = RESULT;
            else if (btn_stand_edge)
                next_state = DEALER_TURN;
        end
        DEALER_TURN: begin
            if (dealer_done)
                next_state = RESULT;
        end
        RESULT: begin
            if (btn_start_edge)
                next_state = IDLE;
        end
        default: begin
            next_state = IDLE;
        end
    endcase
end


// Output logic - controls signals to other modules

always @(*) begin
    deal_card     = 0;
    dealer_go     = 0;
    player_active = 0;
    show_result   = 0;
    result_code   = 2'b00;
    case (state)
        IDLE:        ;
        DEAL:        deal_card     = 1; // deal initial cards
        PLAYER_TURN: begin
            player_active = 1;
            if (btn_hit_edge) deal_card = 1; // one card per press
        end
        DEALER_TURN: dealer_go     = 1;
        RESULT:      show_result   = 1;
        default:     ;
    endcase
end

endmodule