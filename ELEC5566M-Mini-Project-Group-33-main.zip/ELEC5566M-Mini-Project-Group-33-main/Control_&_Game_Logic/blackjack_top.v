// blackjack_top.v
// Author: Muhammad Ayan Tariq

module Blackjack_top (
    input  wire        CLOCK_50,
    input  wire [3:0]  KEY,
    output wire [6:0]  HEX0,
    output wire [6:0]  HEX1,
    output wire [6:0]  HEX2,
    output wire [6:0]  HEX3,
    output wire [6:0]  HEX4,
    output wire [6:0]  HEX5,
    output wire [7:0]  LEDR,
    output wire        LT24Wr_n,
    output wire        LT24Rd_n,
    output wire        LT24CS_n,
    output wire        LT24RS,
    output wire        LT24Reset_n,
    output wire [15:0] LT24Data,
    output wire        LT24LCDOn
);

// Internal wires - FSM control signals

wire        deal_card;
wire        dealer_go;
wire        player_active;
wire        show_result;
wire [1:0]  result_code;
wire [2:0]  state_out;

// Internal wires - card datapath signals

wire [5:0]  player_score;
wire [5:0]  dealer_score;
wire [2:0]  p_cnt, d_cnt;
wire [3:0]  p0, p1, p2, p3, p4;
wire [3:0]  d0, d1, d2, d3, d4;

// player_bust - goes high when player score exceeds 21

wire player_bust;
assign player_bust = (player_score > 6'd21);

// Dealer auto-hit logic
// Pulses deal_dealer every 1 second until dealer score reaches 17
// Then waits 3 seconds and signals dealer_done

reg [27:0] dealer_hit_count;
reg dealer_done_delayed;
reg dealer_pulse;

always @(posedge CLOCK_50 or negedge KEY[3]) begin
    if (!KEY[3]) begin
        dealer_hit_count    <= 0;
        dealer_done_delayed <= 0;
        dealer_pulse        <= 0;
    end else if (state_out == 3'd3) begin
        // In DEALER_TURN
        if (dealer_score >= 6'd17 || dealer_done_delayed == 1) begin
            // Dealer has enough score - stop dealing
            // wait 3 seconds then signal done
            dealer_pulse <= 0;
            if (dealer_hit_count >= 28'd149_999_999) begin
                dealer_done_delayed <= 1;
            end else begin
                dealer_hit_count    <= dealer_hit_count + 1;
                dealer_done_delayed <= 0;
            end
        end else begin
            // Dealer needs more cards - pulse every 1 second
            dealer_done_delayed <= 0;
            if (dealer_hit_count >= 28'd49_999_999) begin
                dealer_hit_count <= 0;
                dealer_pulse     <= 1;
            end else if (dealer_hit_count == 0 && dealer_pulse == 0) begin
                // First card immediately on entry to DEALER_TURN
                dealer_pulse     <= 1;
                dealer_hit_count <= 1;
            end else begin
                dealer_hit_count <= dealer_hit_count + 1;
                dealer_pulse     <= 0;
            end
        end
    end else if (state_out == 3'd4) begin
        // In RESULT state - keep dealer_done HIGH
        dealer_done_delayed <= 1;
        dealer_pulse        <= 0;
    end else begin
        // Not in DEALER_TURN or RESULT - reset everything
        dealer_hit_count    <= 0;
        dealer_done_delayed <= 0;
        dealer_pulse        <= 0;
    end
end

wire dealer_done;
assign dealer_done = dealer_done_delayed;

// Winner logic 
// 2'b01 = WIN
// 2'b00 = LOSS
// 2'b10 = DRAW

reg [1:0] winner;

always @(*) begin
    if (player_score > 6'd21)
        winner = 2'b00;           // player bust — LOSS
    else if (dealer_score > 6'd21)
        winner = 2'b01;           // dealer bust — WIN
    else if (player_score > dealer_score)
        winner = 2'b01;           // player higher — WIN
    else if (dealer_score > player_score)
        winner = 2'b00;           // dealer higher — LOSS
    else
        winner = 2'b10;           // equal — DRAW
end

// FSM instantiation

game_fsm u_game_fsm (
    .clk          (CLOCK_50),
    .reset_n      (KEY[3]),        // KEY[3] is reset (active low)
    .btn_start    (~KEY[0]),       // buttons are active low so invert
    .btn_hit      (~KEY[1]),
    .btn_stand    (~KEY[2]),
    .player_bust  (player_bust),
    .dealer_done  (dealer_done),
    .deal_card    (deal_card),
    .dealer_go    (dealer_go),
    .player_active(player_active),
    .show_result  (show_result),
    .result_code  (result_code),
    .state_out    (state_out)
);

// Card datapath instantiation 
// deal_player connects to deal_card from FSM
// deal_dealer connects to dealer_pulse for auto-hit logic

blackjack_datapath u_datapath (
    .clk          (CLOCK_50),
    .reset        (~KEY[3]),
    .deal_player  (deal_card),
    .deal_dealer  (dealer_pulse),  // auto-hit only - not dealer_go
    .player_score (player_score),
    .dealer_score (dealer_score),
    .player_count (p_cnt),
    .dealer_count (d_cnt),
    .p0(p0), .p1(p1), .p2(p2), .p3(p3), .p4(p4),
    .d0(d0), .d1(d1), .d2(d2), .d3(d3), .d4(d4)
);

// LCD display instantiation 

LT24Top u_display (
    .clock        (CLOCK_50),
    .globalReset  (~KEY[3]),
    .resetApp     (              ),
    .LT24Wr_n     (LT24Wr_n     ),
    .LT24Rd_n     (LT24Rd_n     ),
    .LT24CS_n     (LT24CS_n     ),
    .LT24RS       (LT24RS       ),
    .LT24Reset_n  (LT24Reset_n  ),
    .LT24Data     (LT24Data     ),
    .LT24LCDOn    (LT24LCDOn    ),
    .dealer_score (dealer_score ),
    .player_score (player_score ),
    .player_count (p_cnt        ),
    .dealer_count (d_cnt        ),
    .player_hand_0(p0),
    .player_hand_1(p1),
    .player_hand_2(p2),
    .player_hand_3(p3),
    .player_hand_4(p4),
    .dealer_hand_0(d0),
    .dealer_hand_1(d1),
    .dealer_hand_2(d2),
    .dealer_hand_3(d3),
    .dealer_hand_4(d4),
    .HEX5         (HEX5         ),
    .HEX4         (HEX4         ),
    .HEX1         (HEX1         ),
    .HEX0         (HEX0         ),
    .show_result  (show_result  ),
    .result_code  (winner       )
);

// Unused HEX displays - turn them off

assign HEX2 = 7'b1111111;
assign HEX3 = 7'b1111111;

// Debug LEDs - show FSM state and active signals

assign LEDR[2:0] = state_out;      // state number on LEDs 0-2
assign LEDR[3]   = player_active;  // LED 3 on during player turn
assign LEDR[4]   = dealer_go;      // LED 4 on during dealer turn
assign LEDR[5]   = show_result;    // LED 5 on when result shown
assign LEDR[6]   = player_bust;    // LED 6 on when player busts
assign LEDR[7]   = dealer_done;    // LED 7 on when dealer finishes

endmodule